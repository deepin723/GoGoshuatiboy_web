// app.js
var subjectList = require('data/text.js'); 
App({
  onLaunch() {
    // 展示本地存储能力
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
   
  },
  globalData: {
    token:null,
    items: [],//当前做的题
    userInfo:null,
    chapter:1,
    dp:1,
    book:1,
    bookName:null,
  }
})
