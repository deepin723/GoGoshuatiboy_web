//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
    col:[{color:'cyan'}],
    uimg2_url:"../../resources/logo2.png",
    tip:"未登录",
    showbut2:true,
    elements: [{
      title: '错题本',
      name: 'wrongTopic',
      color: 'cyan',
      icon: 'calendar',
      url:'singleChoice'
    },
    {
      title: '收藏夹',
      name: 'bookmark',
      color: 'cyan',
      icon: 'favorfill',
      url:'study'
    },
    {
      title: '分享小程序',
      name: 'sharing',
      color: 'cyan',
      icon: 'share',
      url:'singleChoice',
    },
    {
      title: '版本更新 ',
      name: 'update',
      color: 'cyan',
      icon: 'down',
      url:'study'
    },
  ],
    userInfo: {}
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../detail/detail'
    })
  },
  onLoad: function () {
    var that = this
    
    
  },
  onShareAppMessage: function () {
    const promise = new Promise(resolve => {
      setTimeout(() => {
        resolve({
          title: '加油刷题仔',
          path: 'pages/index/index',
          imageUrl:'../../resources/sharePic.png',
        })
      }, 20)
    })
    return {
      title: '加油刷题仔',
      path: 'pages/index/index',
      imageUrl:'../../resources/sharePic.png',
      promise 
    }
  },
  onShareTimeline(){
    return{
      title: '加油刷题仔',
      query: 'id=123',
      imageUrl:'../../resources/sharePic.png',
    }
  },
  onShow:function () {

    if(app.globalData.userInfo!=null){
      this.setData({
        uimg2_url:app.globalData.userInfo.avatarUrl,
        tip:app.globalData.userInfo.nickName,
        showbut2:false
      })
    }
  },
  NotYetOpen: function(){
    wx.showModal({
      cancelColor: 'cancelColor',
      showCancel: false,
      content: "该功能还未对外开放"
    })
  },
  wrongbook: function () {
    app.globalData.dp = 4,
      wx.navigateTo({
        url: '/pages/wrongbook/wrongbook',
      })
  },
  Favourite: function () {
    app.globalData.dp=3,
        wx.navigateTo({
          url: '/pages/singleChoice/singleChoice',
        })
      },
  showModal(e) {
    this.setData({
      modalName: e.currentTarget.dataset.target
    })
  },
  hideModal(e) {
    this.setData({
      modalName: null
    })
  },
  
})
