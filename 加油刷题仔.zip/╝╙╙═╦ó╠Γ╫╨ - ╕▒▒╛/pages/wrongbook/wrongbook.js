const app = getApp();
Page({
  data: {
    shows: false, //控制下拉列表的显示隐藏，false隐藏、true显示
    shows1: false,
    selectDatas: ['毛泽东思想理论体系概论', '近代史', '马克思主义基本原理'], //下拉列表的数据
    indexs: 0, //选择的下拉列 表下标,
    indexs1: 0, //选择的下拉列 表下标,
  },
  selectTaps() {
    this.setData({
      shows: !this.data.shows,
    });
  },
  selectTaps1() {
    this.setData({
      shows1: !this.data.shows1,
    });
  },
  // 点击下拉列表
  optionTaps(e) {
    let Indexs = e.currentTarget.dataset.index; //获取点击的下拉列表的下标

    this.setData({
      indexs: Indexs,
      shows: !this.data.shows
    });

  },
  optionTaps1(e) {
    let Indexs1 = e.currentTarget.dataset.index; //获取点击的下拉列表的下标
  
    this.setData({
      indexs1: Indexs1,
      shows1: !this.data.shows1
    });
  },
  myWrong:function(){
    app.globalData.dp=4
if(this.data.indexs==0){app.globalData.book=1}
if(this.data.indexs==1){app.globalData.book=2}
if(this.data.indexs==2){app.globalData.book=3}
wx.navigateTo({
  url: '/pages/singleChoice/singleChoice',
})
  },
  otherWrong:function(){
    app.globalData.dp=5
    if(this.data.indexs1==0){app.globalData.book=1}
    if(this.data.indexs1==1){app.globalData.book=2}
    if(this.data.indexs1==2){app.globalData.book=3}
    wx.navigateTo({
      url: '/pages/singleChoice/singleChoice',
    })
  },
  backhome(){
    wx.navigateBack({
    })
  },
  randomText:function () {
    app.globalData.dp=2
    wx.navigateTo({
      url: '/pages/singleChoice/singleChoice',
    })
  },
  chapter1:function()  {
    app.globalData.chapter=1
    app.globalData.dp=1
    wx.navigateTo({
      url: '/pages/singleChoice/singleChoice',
    })
  },
  chapter2:function()  {
    app.globalData.chapter=2
    app.globalData.dp=1
    wx.navigateTo({
      url: '/pages/singleChoice/singleChoice',
    })
  },
  chapter3:function()  {
    app.globalData.chapter=3
    app.globalData.dp=1
    wx.navigateTo({
      url: '/pages/singleChoice/singleChoice',
    })
  },
  chapter4:function()  {
    app.globalData.chapter=4
    app.globalData.dp=1
    wx.navigateTo({
      url: '/pages/singleChoice/singleChoice',
    })
  },


})
