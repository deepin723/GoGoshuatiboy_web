const app = getApp();
Page({
  data: {
    index: 0,  // 题目序列
    content:null,//题目
    answ:null,//答案
    tishu: 0,//题目数量
    order: [],
    bc_default: 'bg-xmibai',
    bc_right: 'bg-xcyan',
    bc_wrong: 'bg-xred',
    bcA: '',
    bcB: '',
    bcC: '',
    bcD: '',
    bcE: '',
  },
 
  setQuestion: function () {
    var that = this;
    var on = that.data.index;

    this.setData({
      content: that.data.questionList[on].content,//题目
      bcA: that.data.bc_default,
      bcB: that.data.bc_default,
      bcC: that.data.bc_default,
      bcD: that.data.bc_default,
      bcE: that.data.bc_default,
      answ:that.data.questionList[on].answer,
      selectionA:that.data.questionList[on].selection[0],
      selectionB:that.data.questionList[on].selection[1],
      selectionC:that.data.questionList[on].selection[2],
      selectionD:that.data.questionList[on].selection[3],
    })

  },

  shuffle: function (arr) {
    let i = arr.length;
    while (i) {
      let j = Math.floor(Math.random() * i--);
      [arr[j], arr[i]] = [arr[i], arr[j]];
    }
    return arr;
  },

  generateArray: function (start, end) {
    return Array.from(new Array(end + 1).keys()).slice(start)
  },
  showModal(e) {
    this.setData({
      modalName: e.currentTarget.dataset.target
    })
  },

  showModal1(e) {
    this.setData({
      modalName: e.currentTarget.dataset.target
    })
  },


  hideModal(e) {
    this.setData({
      modalName: null
    })
  },

  backhome(){
    wx.navigateBack({
    })
  },
  NavChange(e) {
    this.setData({
      PageCur: e.currentTarget.dataset.cur
    })
  },
  coNavChange(e) {
    this.setData({
      coPageCur: e.currentTarget.dataset.cur
    })
  },
  isCard(e) {
    this.setData({
      isCard: e.detail.value
    })
  },
  SetShadow(e) {
    this.setData({
      shadow: e.detail.valuea
    })
  },
  SetBorderSize(e) {
    this.setData({
      bordersize: e.detail.value
    })
  },
  btnOpClick:function (e) {
    var that = this;
    var on=that.data.index;
    var select = e.currentTarget.id;
    if (select == that.data.questionList[on].answer) {
      if (1) {
        if (select == 'A') {
          this.setData({ bcA: that.data.bc_right });
        }
        else if (select == 'B') {
          this.setData({ bcB: that.data.bc_right });
        }
        else if (select == 'C') {
          this.setData({ bcC: that.data.bc_right });
        }
        else if (select == 'D') {
          this.setData({ bcD: that.data.bc_right });
        }
        else if (select == 'E') {
          this.setData({ bcE: that.data.bc_right });
        }
      }

    }
    else {
      if (select == 'A') {
        this.setData({ bcA: that.data.bc_wrong });
        this.showRight();
      }
      else if (select == 'B') {
        this.setData({ bcB: that.data.bc_wrong });
        this.showRight();
      }
      else if (select == 'C') {
        this.setData({ bcC: that.data.bc_wrong });
        this.showRight();
      }
      else if (select == 'D') {
        this.setData({ bcD: that.data.bc_wrong });
        this.showRight();
      }
      else if (select == 'E') {
        this.setData({ bcE: that.data.bc_wrong });
        this.showRight();
      }
    }
  },
  showRight: function () {
    var that = this;
    var on = that.data.index;
    console.log(that.data.questionList[on].answer)
    if(that.data.questionList[on].answer=='A')
    this.setData({bcA:that.data.bc_right});
    if(that.data.questionList[on].answer=='B')
    this.setData({bcB:that.data.bc_right});
    if(that.data.questionList[on].answer=='C')
    this.setData({bcC:that.data.bc_right});
    if(that.data.questionList[on].answer=='D')
    this.setData({bcD:that.data.bc_right})
  },
  nextSubmit: function () {
var that=this;


    // 判断是不是最后一题
    if (1) {
      // 渲染下一题
      this.setData({
        index: this.data.index + 1
      })
      this.setQuestion()
      console.log(that.data.index)
    } 
  },
  onLoad: function (options) {

    this.setData({
      questionList: app.globalData.questionList[options.testId], // 拿到答题数据
      testId: options.testId,// 课程ID
    })
    console.log(this.data.questionList.length);
    console.log(this.data.questionList[0].content)
    this.setData({
     tishu:this.data.questionList.length
    })
    this.setQuestion()

  },
});

