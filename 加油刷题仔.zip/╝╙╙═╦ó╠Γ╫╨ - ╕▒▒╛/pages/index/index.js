const app = getApp();
Page({
  data: {
    StatusBar: app.globalData.StatusBar,
    ColorList: app.globalData.ColorList,
    CustomBar: app.globalData.CustomBar,
    CustomBar: app.globalData.CustomBar,
    uimg_url: "../../resources/logo.png",
    tip: "登录使用全部功能",
    book1: '毛泽东思想理论体系概论',
    num1: 1,
    isLike: [],
    appreciateNum1:0,
    appreciateNum2:0,
    appreciateNum3:0,
    iconAppreciate1:'cuIcon-appreciate',
    iconAppreciate2:'cuIcon-appreciate',
    iconAppreciate3:'cuIcon-appreciate',
    icon: [{
      name: 'appreciate',
      isShow: true
    }, {
      name: 'commentfill',
      isShow: true
    }, {
      name: 'forward',
      isShow: true
    },],
    showbut1: true,
    avatarUrl1: null,
    nickName1: null,
    temComment:null,
  },
  book1Comment: function () {
    var on = this.data.index;
    wx.request({
      method: "POST",
      url: 'https://shuati.diaoan.xyz/api/postCommentBook',
      data: {
        token: app.globalData.token,
        comment: this.data.temComment,
        book: 1
      },
      header: { "Content-Type": "application/json" },
      success: function (res) {
        wx.showToast({
          title: '您的建议是我们前进的动力',
          icon: 'none',
          duration: 1000
        });
      }
    });
    this.hideModal()
    this.setData({
      inputValue: [],
      temComment:[],
    })
  },

book2Comment: function () {
    var on = this.data.index;
    wx.request({
      method: "POST",
      url: 'https://shuati.diaoan.xyz/api/postCommentBook',
      data: {
        token: app.globalData.token,
        comment: this.data.temComment,
        book: 2
      },
      header: { "Content-Type": "application/json" },
      success: function (res) {
        wx.showToast({
          title: '您的建议是我们前进的动力',
          icon: 'none',
          duration: 1000
        });
      }
    });
    this.hideModal()
    this.setData({
      inputValue: [],
      temComment:[],
    })
  },
  
  book3Comment: function () {
    var on = this.data.index;
    wx.request({
      method: "POST",
      url: 'https://shuati.diaoan.xyz/api/postCommentBook',
      data: {
        token: app.globalData.token,
        comment: this.data.temComment,
        book: 3
      },
      header: { "Content-Type": "application/json" },
      success: function (res) {
        wx.showToast({
          title: '您的建议是我们前进的动力',
          icon: 'none',
          duration: 1000
        });
      }
    });
    this.hideModal()
    this.setData({
      inputValue: [],
      temComment:[],
    })
  },
  transfer(e) {
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline'],
      success() {
      }
    })
  },
    textareaAInput(e) {
    this.setData({
      textareaAValue: e.detail.value
    })
  },
  showModal(e) {
    this.setData({
      modalName: e.currentTarget.dataset.target
    })
  },
  hideModal(e) {
    this.setData({
      modalName: null
    })
  },
  onShareAppMessage: function () {
    const promise = new Promise(resolve => {
      setTimeout(() => {
        resolve({
          title: '加油刷题仔',
          path: 'pages/index/index',
          imageUrl: '../../resources/sharePic.png',
        })
      }, 20)
    })
    return {
      title: '加油刷题仔',
      path: 'pages/index/index',
      imageUrl: '../../resources/sharePic.png',
      promise
    }
  },
  onLoad(res) {
    this.getUserInfo()
    var that = this;
    this.transfer()
  },
  getUserInfo() {
    var that = this
    //获取token
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
        if (res.code) {
          //发起网络请求
          wx.request({
            url: 'https://shuati.diaoan.xyz/api/wxLogin',
            method: 'POST',
            data: {
              code: res.code //将code发给后台拿token
            },
            header: {
              'content-type': 'application/json' // 默认值
            },
            success: function (res) {
              wx.request({
                method: "POST",
                url: 'https://shuati.diaoan.xyz/api/getBooks',
                data: {
                  token: res.data.token,
                },
                header: { "Content-Type": "application/json" },
                success: function (res) {
                  that.setData({
                    appreciateNum1:res.data[0].likes,
                    appreciateNum2:res.data[1].likes,
                    appreciateNum3:res.data[2].likes
                  })
                    if(res.data[0].liked==1){
                    that.setData({
                      iconAppreciate1:'cuIcon-appreciatefill',
                    })
                    }
                    if(res.data[1].liked==1){
                      that.setData({
                        iconAppreciate2:'cuIcon-appreciatefill',
                      })
                      }
                      if(res.data[2].liked==1){
                        that.setData({
                          iconAppreciate3:'cuIcon-appreciatefill',
                        })
                        }
                  that.data.book1 = res.data[0].name
                  that.data.num1 = res.data[0].id
                }
              });
              wx.request({
                method: "GET",
                url: 'https://shuati.diaoan.xyz/api/getUser',
                data: {
                  token: res.data.token,
                },
                header: { "Content-Type": "application/json" },
                success: function (res) {
                  if (res.data.data.avatar) {
                    that.setData({
                      uimg_url: res.data.data.avatar,
                      tip: res.data.data.nickName + " 加油哦!",
                      showbut1: false
                    })
                    app.globalData.userInfo = {};
                    app.globalData.userInfo.avatarUrl = res.data.data.avatar,
                      app.globalData.userInfo.nickName = res.data.data.nickName,
                      app.globalData.token = res.data.data.token
                  } else {
                    wx.showModal({
                      cancelColor: 'cancelColor',
                      title: "请先登录",
                      success(res) {
                        that.getUserProfile()
                      }
                    })
                  }
                  //能拿到头像和用户名,具体你看res里面
                }
              });
              //拿到后将token存入全局变量  以便其他页面使用
            },
          })
        } else {
          wx.showToast({
            title: '当前网络状况不佳',
            icon: 'error',
            duration: 1000
          });
        }
      }
    })
  },
  getinput(event) {
    this.data.temComment = event.detail.value
},
  isCard(e) {
    this.setData({
      isCard: e.detail.value
    })
  },
  SetShadow(e) {
    this.setData({
      shadow: e.detail.value
    })
  },
  btnStart2: function () {
    app.globalData.book = 2,
      wx.navigateTo({
        url: '/pages/catalogue2/catalogue2',
      })
  },
  btnStart3: function () {
    app.globalData.book = 3,
      wx.navigateTo({
        url: '/pages/catalogue3/catalogue3',
      })
  },
  btnStart1: function () {
    app.globalData.book = 1,
      wx.navigateTo({
        url: '/pages/catalogue/catalogue',
      })
  },
  appreciate1:function(){
    var that =this;
    if(that.data.iconAppreciate1=='cuIcon-appreciate'){
    wx.request({
     method: "POST",
     url: 'https://shuati.diaoan.xyz/api/addLike',
     data: {
       type: 2,
       token: app.globalData.token,
       object:1,
     },
     header: { "Content-Type": "application/json" },
     success: function (res) {
         that.setData({
             iconAppreciate1:'cuIcon-appreciatefill',
             appreciateNum1:that.data.appreciateNum1+1
         })

     }
   });
  }
},
appreciate2:function(){
  var that =this;
  if(that.data.iconAppreciate2=='cuIcon-appreciate'){
  wx.request({
   method: "POST",
   url: 'https://shuati.diaoan.xyz/api/addLike',
   data: {
     type: 2,
     token: app.globalData.token,
     object:2,
   },
   header: { "Content-Type": "application/json" },
   success: function (res) {
       that.setData({
           iconAppreciate2:'cuIcon-appreciatefill',
           appreciateNum2:that.data.appreciateNum2+1
       })

   }
 });
}
},
appreciate3:function(){
  var that =this;
  if(that.data.iconAppreciate3=='cuIcon-appreciate'){
  wx.request({
   method: "POST",
   url: 'https://shuati.diaoan.xyz/api/addLike',
   data: {
     type: 2,
     token: app.globalData.token,
     object:3,
   },
   header: { "Content-Type": "application/json" },
   success: function (res) {
       that.setData({
           iconAppreciate3:'cuIcon-appreciatefill',
           appreciateNum3:that.data.appreciateNum3+1
       })
   }
 });
}
},

  getUserProfile: function (e) {
    var that = this;
    wx.getUserProfile({
      desc: '用于获取用户信息', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        // 登录成功
        // console.log(res)
        this.data.avatarUrl1 = res.userInfo.avatarUrl
        this.data.nickName1 = res.userInfo.nickName
        wx.login({
          success: res => {
            // 发送 res.code 到后台换取 openId, sessionKey, unionId
            if (res.code) {
              //发起网络请求
              wx.request({
                url: 'https://shuati.diaoan.xyz/api/wxLogin',
                method: 'POST',
                data: {
                  code: res.code //将code发给后台拿token
                },
                header: {
                  'content-type': 'application/json' // 默认值
                },
                success: function (res) {
                  console.log('token=' + res.data.token)
                  app.globalData.token = res.data.token,
                    console.log(app.globalData.token)
                  wx.request({
                    method: "post",
                    url: 'https://shuati.diaoan.xyz/api/syncUserInfo',
                    data: {
                      token: app.globalData.token,
                      avatar: that.data.avatarUrl1,
                      nickname: that.data.nickName1,
                    },
                    header: { "Content-Type": "application/json" },
                    success: function (res) {
                      console.log("传输成功")
                    }
                  });
                  //拿到后将token存入全局变量  以便其他页面使用
                },
              })
            } else {
              wx.showToast({
                title: '当前网络状况不佳',
                icon: 'error',
                duration: 1000
              });
            }
          }
        })

        app.globalData.userInfo = res.userInfo


        if (res.userInfo.avatarUrl) {
          this.setData({
            uimg_url: res.userInfo.avatarUrl,
            tip: res.userInfo.nickName + " 加油哦!",
            showbut1: false
          })
        }

      }
    })
  },
  SetBorderSize(e) {
    this.setData({
      bordersize: e.detail.value
    })
  }
});