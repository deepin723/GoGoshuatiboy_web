const app = getApp();
Page({
  data: {
    StatusBar: app.globalData.StatusBar,
    ColorList: app.globalData.ColorList,
    CustomBar: app.globalData.CustomBar,

    icon: [{ name: 'favor', isShow: true },{ name: 'edit', isShow: true },{ name: 'favor', isShow: true },{ name: 'comment', isShow: true }],

    checkbox: [{
      value: 0,
      name: 'A.支持自定义APP和应用程序名称',
      checked: false,
    }, {
      value: 1,
      name: 'B.支持自定义包含版权声明页的所有logo及所有权主体声明',
      checked: false,
    }, {
      value: 2,
      name: 'C.支持自定义APP和应用程序logo',
      checked: false,
    }, {
      value: 3,
      name: 'D.支持自定义启动闪屏页',
      checked: false,
    }, ]
  },

  showModal(e) {
    this.setData({
      modalName: e.currentTarget.dataset.target
    })
  },


  hideModal(e) {
    this.setData({
      modalName: null
    })
  },

  ChooseCheckbox(e) {
    let items = this.data.checkbox;
    let values = e.currentTarget.dataset.value;
    for (let i = 0, lenI = items.length; i < lenI; ++i) {
      if (items[i].value == values) {
        items[i].checked = !items[i].checked;
        break
      }
    }
    this.setData({
      checkbox: items
    })
  },
  answercheck(e) {
    let items = this.data.checkbox;
    let values = e.currentTarget.dataset.value;
    this.data.checkbox[0].checked=true,
    this.data.checkbox[2].checked=true,
    this.data.checkbox[3].checked=true,
    this.setData({
      checkbox: items
    })
  },
 
  NavChange(e) {
    this.setData({
      PageCur: e.currentTarget.dataset.cur
    })
  },
  coNavChange(e) {
    this.setData({
      coPageCur: e.currentTarget.dataset.cur
    })
  },
  isCard(e) {
    this.setData({
      isCard: e.detail.value
    })
  },
  SetShadow(e) {
    this.setData({
      shadow: e.detail.valuea
    })
  },
  SetBorderSize(e) {
    this.setData({
      bordersize: e.detail.value
    })
  }
});

