const app = getApp();
Page({
  backhome(){
    wx.navigateBack({
    })
  },
  randomText:function () {
    app.globalData.dp=2
    wx.navigateTo({
      url: '/pages/singleChoice/singleChoice',
    })
  },
  chapter1:function()  {
    app.globalData.chapter=1
    app.globalData.dp=1
    wx.navigateTo({
      url: '/pages/singleChoice/singleChoice',
    })
  },
  chapter2:function()  {
    app.globalData.chapter=2
    app.globalData.dp=1
    wx.navigateTo({
      url: '/pages/singleChoice/singleChoice',
    })
  },
  chapter3:function()  {
    app.globalData.chapter=3
    app.globalData.dp=1
    wx.navigateTo({
      url: '/pages/singleChoice/singleChoice',
    })
  },
  chapter4:function()  {
    app.globalData.chapter=4
    app.globalData.dp=1
    wx.navigateTo({
      url: '/pages/singleChoice/singleChoice',
    })
  },
  chapter5:function()  {
    app.globalData.chapter=5
    app.globalData.dp=1
    wx.navigateTo({
      url: '/pages/singleChoice/singleChoice',
    })
  },
  chapter6:function()  {
    app.globalData.chapter=6
    app.globalData.dp=1
    wx.navigateTo({
      url: '/pages/singleChoice/singleChoice',
    })
  },
  chapter7:function()  {
    app.globalData.chapter=7
    app.globalData.dp=1
    wx.navigateTo({
      url: '/pages/singleChoice/singleChoice',
    })
  },
  chapter8:function()  {
    app.globalData.chapter=8
    app.globalData.dp=1
    wx.navigateTo({
      url: '/pages/singleChoice/singleChoice',
    })
  },
  chapter9:function()  {
    app.globalData.chapter=9
    app.globalData.dp=1
    wx.navigateTo({
      url: '/pages/singleChoice/singleChoice',
    })
  },
  chapter10:function()  {
    app.globalData.chapter=10
    app.globalData.dp=1
    wx.navigateTo({
      url: '/pages/singleChoice/singleChoice',
    })
  },
  chapter11:function()  {
    app.globalData.chapter=11
    app.globalData.dp=1
    wx.navigateTo({
      url: '/pages/singleChoice/singleChoice',
    })
  },
  chapter12:function()  {
    app.globalData.chapter=12
    app.globalData.dp=1
    wx.navigateTo({
      url: '/pages/singleChoice/singleChoice',
    })
  },
  chapter13:function()  {
    app.globalData.chapter=13
    app.globalData.dp=1
    wx.navigateTo({
      url: '/pages/singleChoice/singleChoice',
    })
  },
  chapter14:function()  {
    app.globalData.chapter=14
    app.globalData.dp=1
    wx.navigateTo({
      url: '/pages/singleChoice/singleChoice',
    })
  },

})
