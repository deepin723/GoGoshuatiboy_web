const app = getApp();
import MinaTouch from '../../colorui/mina-touch/index';

Page({
    data: {
        translateX: 0,
        index: 0,  // 题目序列
        content: null,//题目
        answ: null,//答案
        tishu: 0,//题目数量
        order: [],
        bc_default: 'bg-xmibai',
        bc_right: 'bg-xcyan',
        bc_wrong: 'bg-xred',
        bcA: '',
        bcB: '',
        bcC: '',
        bcD: '',
        bcE: '',
        textId: null,
        questionList: [],
        type: 0,//题目类型
        userAnswer: [],
        showtx: false,
        temComment: [],
        inputValue: [],
        nickname1: '华农学籽',
        avatar1: '/resources/logo.png',
        creatTime: null,
        like1: 0,
        userComment: '沙发空荡荡的，快来发布第一条评论吧',
        commentNum: 0,
        usersComment: [],
        star: 'star1',
        iconAppreciate: 'cuIcon-appreciate',
        acom: [],
        Click: true,
        InputBottom: 0,
        booknum:1,
        chapter:1,
        cobooknum:1,
        coChapter:1,
        swipeT:true,
    },

    setQuestion: function () {
        var that = this;
        var on = that.data.index;
        this.setData({
            content: that.data.questionList[on].content,//题目
            bcA: that.data.bc_default,
            bcB: that.data.bc_default,
            bcC: that.data.bc_default,
            bcD: that.data.bc_default,
            bcE: that.data.bc_default,
            answ: that.data.questionList[on].answer,
            selectionA: that.data.questionList[on].selection[0],
            selectionB: that.data.questionList[on].selection[1],
            selectionC: that.data.questionList[on].selection[2],
            selectionD: that.data.questionList[on].selection[3],
            selectionE: that.data.questionList[on].selection[4],
            selectNum: that.data.questionList[on].selection.length,
            tishu: that.data.questionList.length,
            type: that.data.questionList[on].type,
            acom: [],
            Click: true,
            showtx: false,
            booknum:app.globalData.book,
            chapter:app.globalData.chapter,
            dp:app.globalData.dp,
            cobooknum:that.data.questionList[on].book,
            coChapter:that.data.questionList[on].chapter,
            swipeT:true,
        })
        if (that.data.questionList[on].favourite == 0) {
            this.setData({
                star: 'star1'
            })
        }
        else if (that.data.questionList[on].favourite == 1) {
            this.setData({
                star: 'star'
            })
        }
        wx.request({
            method: "POST",
            url: 'https://shuati.diaoan.xyz/api/getComment',
            data: {
                token: app.globalData.token,
                qid: this.data.questionList[on].id
            },
            header: { "Content-Type": "application/json" },
            success: function (res) {
                that.setData({
                    usersComment: res.data.body,
                    commentNum: res.data.body.length
                })
                for (var i = 0; i < that.data.commentNum; i++) {
                    if (res.data.body[i].liked == 1) {
                        that.setData({
                            acom: [...that.data.acom, 1]
                        })
                    }
                    else {
                        that.setData({
                            acom: [...that.data.acom, 0]
                        })
                    }
                }
            }
        });

    },




    showModal(e) {
        this.setData({
            modalName: e.currentTarget.dataset.target
        })
    },

    showModal1(e) {
        this.setData({
            modalName: e.currentTarget.dataset.target
        })
    },


    hideModal(e) {
        this.setData({
            modalName: null
        })
    },

    backhome() {
        wx.navigateBack({
        })
    },
    NavChange(e) {
        this.setData({
            PageCur: e.currentTarget.dataset.cur
        })
    },
    // coNavChange(e) {
    //   this.setData({
    //     coPageCur: e.currentTarget.dataset.cur
    //   })
    // },
    isCard(e) {
        this.setData({
            isCard: e.detail.value
        })
    },
    SetShadow(e) {
        this.setData({
            shadow: e.detail.valuea
        })
    },
    SetBorderSize(e) {
        this.setData({
            bordersize: e.detail.value
        })
    },
    changeSub: function (e) {
        var that = this;
        var on = that.data.index;
        var selectNum = e.currentTarget.id;
        this.setData({
            index: selectNum - 1
        })
        this.setQuestion()
        this.hideModal()
    },
    adDeFavourite: function () {
        var that = this
        var on = that.data.index;
        if (that.data.star == 'star1') {
            wx.request({
                method: "post",
                url: 'https://shuati.diaoan.xyz/api/addFavourite',
                data: {
                    token: app.globalData.token,
                    id: that.data.questionList[on].id,
                },
                header: { "Content-Type": "application/json" },
                success: function (res) {
                    that.setData({
                        star: 'star'
                    })
                    //显示收藏成功
                    wx.showToast({
                        title: '收藏成功',
                        icon: 'none',
                        duration: 1000
                    });
                }
            });
        }
        else if (that.data.star == 'star') {
            wx.request({
                method: "post",
                url: 'https://shuati.diaoan.xyz/api/removeFavourite',
                data: {
                    token: app.globalData.token,
                    id: that.data.questionList[on].id,
                },
                header: { "Content-Type": "application/json" },
                success: function (res) {
                    that.setData({
                        star: 'star1'
                    })
                    //显示取消收藏
                    wx.showToast({
                        title: '已取消收藏',
                        icon: 'none',
                        duration: 1000
                    });
                }
            });
        }
    },
    //单选题
    btnOpClick1: function (e) {
        var that = this;
        var on = that.data.index;
        var select = e.currentTarget.id;
        if (that.data.Click) {
            if (select == that.data.questionList[on].answer) {
                if (1) {
                    if (select == 'A') {
                        this.setData({
                            bcA: that.data.bc_right,
                            Click: false
                        });
                        this.show()
                        setTimeout(function () {
                            
                            that.nextSubmit()
                        }, 1000)
                    }
                    else if (select == 'B') {
                        this.setData({
                            bcB: that.data.bc_right,
                            Click: false
                        });
                        this.show()
                        setTimeout(function () {
                            
                            that.nextSubmit()
                        }, 1000)
                    }
                    else if (select == 'C') {
                        this.setData({
                            bcC: that.data.bc_right,
                            Click: false
                        });
                        this.show()
                        setTimeout(function () {
                            
                            that.nextSubmit()
                        }, 1000)
                    }
                    else if (select == 'D') {
                        this.setData({
                            bcD: that.data.bc_right,
                            Click: false
                        });
                        this.show()
                        setTimeout(function () {
                            
                            that.nextSubmit()
                        }, 1000)
                    }
                    else if (select == 'E') {
                        this.setData({
                            bcE: that.data.bc_right,
                            Click: false
                        });
                        this.show()
                        setTimeout(function () {
                            
                            that.nextSubmit()
                        }, 1000)

                    }
                }

            }
            else {
                wx.showToast({
                    title: '答错了',
                    icon: 'none',
                    duration: 1000
                });
                wx.request({
                    method: "POST",
                    url: 'https://shuati.diaoan.xyz/api/saveUserRecord',
                    data: {
                      token: app.globalData.token,
                      qid:that.data.questionList[on].id
                    },
                    header: { "Content-Type": "application/json" },
                    success: function (res) {
                    }
                  });
                if (select == 'A') {
                    this.setData({ bcA: that.data.bc_wrong });
                    this.showRight1();
                }
                else if (select == 'B') {
                    this.setData({ bcB: that.data.bc_wrong });
                    this.showRight1();
                }
                else if (select == 'C') {
                    this.setData({ bcC: that.data.bc_wrong });
                    this.showRight1();
                }
                else if (select == 'D') {
                    this.setData({ bcD: that.data.bc_wrong });
                    this.showRight1();
                }
                else if (select == 'E') {
                    this.setData({ bcE: that.data.bc_wrong });
                    this.showRight1();
                }
            }
        }
    },
    //多选题
    btnOpClick2: function (e) {
        var that = this;
        var select = e.currentTarget.id;
        var a = that.data.userAnswer.indexOf(select);
        if (that.data.Click) {
            if (a < 0) {
                that.data.userAnswer.push(select);
                if (select == 'A') {
                    this.setData({ bcA: that.data.bc_right });
                }
                else if (select == 'B') {
                    this.setData({ bcB: that.data.bc_right });
                }
                else if (select == 'C') {
                    this.setData({ bcC: that.data.bc_right });
                }
                else if (select == 'D') {
                    this.setData({ bcD: that.data.bc_right });
                }
                else if (select == 'E') {
                    this.setData({ bcE: that.data.bc_right });
                }
                else if (select == 'F') {
                    this.setData({ bcF: that.data.bc_right });
                }
            }
            if (a >= 0) {
                var item = that.data.userAnswer.splice(that.data.userAnswer.indexOf(select), 1);
                if (select == 'A') {
                    this.setData({ bcA: that.data.bc_default });
                }
                else if (select == 'B') {
                    this.setData({ bcB: that.data.bc_default });
                }
                else if (select == 'C') {
                    this.setData({ bcC: that.data.bc_default });
                }
                else if (select == 'D') {
                    this.setData({ bcD: that.data.bc_default });
                }
                else if (select == 'E') {
                    this.setData({ bcE: that.data.bc_default });
                }
                else if (select == 'F') {
                    this.setData({ bcF: that.data.bc_default });
                }
                //从答案中去除该选项
            }
        }
    },
    showRight1 : function () {
        this.setData({
            showtx: true,
            Click: false
        })
        var that = this;
        var on = that.data.index;
        if (that.data.questionList[on].answer.indexOf('A') >= 0) {
            this.setData({ bcA: that.data.bc_right, });
        }

        if (that.data.questionList[on].answer.indexOf('B') >= 0) {
            this.setData({ bcB: that.data.bc_right, });
        }

        if (that.data.questionList[on].answer.indexOf('C') >= 0) {
            this.setData({ bcC: that.data.bc_right, });
        }

        if (that.data.questionList[on].answer.indexOf('D') >= 0) {
            this.setData({ bcD: that.data.bc_right, });
        }
 
        if (that.data.questionList[on].answer.indexOf('E') >= 0) {
            this.setData({ bcE: that.data.bc_right, });
        }

    },
    showRight: function () {
        this.setData({
            showtx: true,
            Click: false
        })
        var that = this;
        var on = that.data.index;
        if (that.data.questionList[on].answer.indexOf('A') >= 0) {
            this.setData({ bcA: that.data.bc_right, });
        }
        else{
            this.setData({ bcA: that.data.bc_default, });
        }
        if (that.data.questionList[on].answer.indexOf('B') >= 0) {
            this.setData({ bcB: that.data.bc_right, });
        }
        else{
            this.setData({ bcB: that.data.bc_default, });
        }
        if (that.data.questionList[on].answer.indexOf('C') >= 0) {
            this.setData({ bcC: that.data.bc_right, });
        }
        else{
            this.setData({ bcC: that.data.bc_default, });
        }
        if (that.data.questionList[on].answer.indexOf('D') >= 0) {
            this.setData({ bcD: that.data.bc_right, });
        }
        else{
            this.setData({ bcD: that.data.bc_default, });
        }
        if (that.data.questionList[on].answer.indexOf('E') >= 0) {
            this.setData({ bcE: that.data.bc_right, });
        }
        else{
            this.setData({ bcE: that.data.bc_default, });
        }
    },
    isRight() {
        var that = this;
        var on = that.data.index;
        if (1) {
            var jo=true
            for (var i = 0; i < 5; i++) {
                if (that.data.userAnswer.indexOf(that.data.questionList[on].answer.charAt(i)) < 0) {
                    

                    if ((that.data.userAnswer.indexOf('A') >= 0)&&(that.data.questionList[on].answer.indexOf('A') < 0))
                        this.setData({ bcA: that.data.bc_wrong });
                    if ((that.data.userAnswer.indexOf('B') >= 0)&&(that.data.questionList[on].answer.indexOf('B') < 0))
                        this.setData({ bcB: that.data.bc_wrong });
                    if ((that.data.userAnswer.indexOf('C') >= 0)&&(that.data.questionList[on].answer.indexOf('C') < 0))
                        this.setData({ bcC: that.data.bc_wrong });
                    if ((that.data.userAnswer.indexOf('D') >= 0)&&(that.data.questionList[on].answer.indexOf('D') < 0))
                        this.setData({ bcD: that.data.bc_wrong });
                    if ((that.data.userAnswer.indexOf('E') >= 0)&&(that.data.questionList[on].answer.indexOf('E') < 0))
                        this.setData({ bcE: that.data.bc_wrong });
                    if (that.data.questionList[on].answer.indexOf('A') >= 0)
                        this.setData({ bcA: that.data.bc_right });
                    if (that.data.questionList[on].answer.indexOf('B') >= 0)
                        this.setData({ bcB: that.data.bc_right });
                    if (that.data.questionList[on].answer.indexOf('C') >= 0)
                        this.setData({ bcC: that.data.bc_right });
                    if (that.data.questionList[on].answer.indexOf('D') >= 0)
                        this.setData({ bcD: that.data.bc_right });
                    if (that.data.questionList[on].answer.indexOf('E') >= 0)
                        this.setData({ bcE: that.data.bc_right });
                }
            }
            if (that.data.userAnswer.length == that.data.questionList[on].answer.length) {
                for (var i = 0; i < that.data.questionList[on].answer.length; i++) {
                    if (that.data.userAnswer.indexOf(that.data.questionList[on].answer.charAt(i)) < 0) {
                        break
                    }
                }
                if (i == that.data.questionList[on].answer.length) {
                    this.show()
                    //标记答对
                    setTimeout(function () {
                        
                        that.nextSubmit()
                    }, 1000)
                }
                else {
                    wx.showToast({
                        title: '答错了',
                        icon: 'none',
                        duration: 1000
                    });
                    wx.request({
                        method: "POST",
                        url: 'https://shuati.diaoan.xyz/api/saveUserRecord',
                        data: {
                          token: app.globalData.token,
                          qid:that.data.questionList[on].id
                        },
                        header: { "Content-Type": "application/json" },
                        success: function (res) {


    
                        }
                      });
              }
            }
            else {
                wx.showToast({
                    title: '答错了',
                    icon: 'none',
                    duration: 1000
                });
                wx.request({
                    method: "POST",
                    url: 'https://shuati.diaoan.xyz/api/saveUserRecord',
                    data: {
                      token: app.globalData.token,
                      qid:that.data.questionList[on].id
                    },
                    header: { "Content-Type": "application/json" },
                    success: function (res) {
                    }
                  });
          }
        }
    },

    appreciate: function (e) {
        var that = this;
        var j=e.target.dataset.seetdata
        
        if(that.data.acom[j]==0){
          let index1 = j;
          let temp = 'usersComment[' + index1 + '].like'
          that.setData({
              [temp]: that.data.usersComment[index1].like + 1
          })
        }
        wx.request({
            method: "POST",
            url: 'https://shuati.diaoan.xyz/api/addLike',
            data: {
                type: 1,
                token: app.globalData.token,
                object: that.data.usersComment[e.target.dataset.seetdata].id,
            },
            header: { "Content-Type": "application/json" },
            success: function (res) {

                let temp = 'acom[' + e.target.dataset.seetdata + ']'
                that.setData({
                    [temp]: 1
                })
                //点赞成功
            }
        });
    },
    getinput(event) {
        this.data.temComment = event.detail.value
    },
    submit: function () {
        // if(this.data.userAnswer==null){

        // }
        if(this.data.Click){
          if(this.data.userAnswer.length>0){
        this.setData({
            showtx: true,
            Click: false
        })
        this.isRight();
      }
      else{
        wx.showToast({
          title: '请至少选一个答案',
          icon: 'none',
          duration: 1000
      });
      }
      }
    },

    nextSubmit: function () {//下一题
        var that = this;
        // 判断是不是最后一题
        if (this.data.index + 1 < that.data.questionList.length) {
            // 渲染下一题
            this.setData({
                showtx: false,
                index: this.data.index + 1,
                userAnswer: [],
            })
            this.setQuestion()
        }
        else {
            wx.showToast({
                title: '这是最后一题啦',
                icon: 'none',
                duration: 1000
            });
        }
    },
    show: function () {
        this.setData({
            swipeT:false
        })
        wx.showToast({
            title: '答对了',
            icon: 'none',
            duration: 1000
        });
    },
    
    lastSubmit: function () {//上一题
        var that = this;
        // 判断是不是第一题
        if (this.data.index + 1 > 1) {
            // 渲染上一题
            this.setData({
                showtx: false,
                index: this.data.index - 1,
                userAnswer: [],
            })
            this.setQuestion()
        }
        else {
            wx.showToast({
                title: '这是第一题啦',
                icon: 'none',
                duration: 1000
            });
        }
    },

    send: function () {
        var on = this.data.index;
        if(this.data.temComment.length>0){
        wx.request({
            method: "POST",
            url: 'https://shuati.diaoan.xyz/api/postComment',
            data: {
                token: app.globalData.token,
                comment: this.data.temComment,
                qid: this.data.questionList[on].id
            },
            header: { "Content-Type": "application/json" },
            success: function (res) {
                wx.showToast({
                    title: '评论经审核后可显示在评论区',
                    icon: 'none',
                    duration: 1000
                });
            }
        });
      }
      else{
        wx.showToast({
          title: '请输入内容后发送',
          icon: 'none',
          duration: 1000
      });
      }
        this.setData({
            inputValue: [],
            temComment:[],
        })
    },
    InputFocus(e) {
        this.setData({
            InputBottom: e.detail.height
        })
    },
    InputBlur(e) {
        this.setData({
            InputBottom: 0
        })
    },
    onLoad: function (options) {
        const that = this;
        if (app.globalData.dp == 1) {
            wx.request({
                method: "GET",
                url: 'https://shuati.diaoan.xyz/api/getQuestion',
                data: {
                    token: app.globalData.token,
                    book: app.globalData.book,
                    chapter: app.globalData.chapter,
                },
                header: { "Content-Type": "application/json" },
                success: function (res) {
                    // 存token
                    that.data.questionList = res.data.body;
                    that.setQuestion()
                }
            });
        }
        else if (app.globalData.dp == 2) {
            wx.request({
                method: "GET",
                url: 'https://shuati.diaoan.xyz/api/getRandomQuestion',
                data: {
                    book: app.globalData.book,
                    token: app.globalData.token,
                },
                header: { "Content-Type": "application/json" },
                success: function (res) {
                    that.data.questionList = res.data.body;
                    that.setQuestion()
                }
            });
        }
        else if (app.globalData.dp == 3) {
            //收藏夹窗口
            var on=this.data.index;
            wx.request({
                method: "GET",
                url: 'https://shuati.diaoan.xyz/api/getFavouritesAll',
                data: {
                    token: app.globalData.token,

                },
                header: { "Content-Type": "application/json" },
                success: function (res) {

                    that.data.questionList = res.data.body;
                    that.setQuestion()
                    app.globalData.book=res.data.body[on].book
                    app.globalData.chapter=res.data.body[on].chapter
                }
            });
        }
        else if (app.globalData.dp == 4) {
            var on=this.data.index;
            wx.request({
                method: "GET",
                url: 'https://shuati.diaoan.xyz/api/getMostWrongPersonal',
                data: {
                    token: app.globalData.token,
                    book:app.globalData.book

                },
                header: { "Content-Type": "application/json" },
                success: function (res) {
                    that.data.questionList = res.data.body;
                    that.setQuestion()
                    app.globalData.book=res.data.body[on].book
                    app.globalData.chapter=res.data.body[on].chapter
                }
            });
        }
        else if (app.globalData.dp == 5) {
            var on=this.data.index;
            wx.request({
                method: "GET",
                url: 'https://shuati.diaoan.xyz/api/getMostWrongGlobal',
                data: {
                    token: app.globalData.token,
                    book:app.globalData.book

                },
                header: { "Content-Type": "application/json" },
                success: function (res) {
                    that.data.questionList = res.data.body;
                    that.setQuestion()
                    app.globalData.book=res.data.body[on].book
                    app.globalData.chapter=res.data.body[on].chapter
                }
            });
        }
        new MinaTouch(this, 'touch1', {
            //会创建this.touch1指向实例对象
            touchStart: function () { },
            touchMove: function () { },
            touchEnd: function () { },
            touchCancel: function () { },
            multipointStart: function () {
            }, //一个手指以上触摸屏幕触发
            multipointEnd: function () {
            }, //当手指离开，屏幕只剩一个手指或零个手指触发(一开始只有一根手指也会触发)

            swipe: function (evt) {
                //在touch结束触发，evt.direction代表滑动的方向 ['Up','Right','Down','Left']
                if(that.data.swipeT){
                if (evt.direction == 'Left') {
                    that.nextSubmit()
                } else if (evt.direction == 'Right') {
                    that.lastSubmit()
                }
            }
            },
        });
    },
});

